# AutoStudio — MVP gratuito sin PC ni APIs de pago

Este prototipo **no es una IA autónoma de investigación**. Es una prueba verificable del motor de montaje CPU: 3 escenas originales programáticas, voz castellana gratuita con `espeak-ng`, zoom y MP4 vertical 720×1280. No publica en YouTube.

## Desde un móvil Android

1. Crear un repositorio **público** vacío en GitHub. Un repositorio público deja visible el código y los guiones; **no incluir datos personales, credenciales ni información privada**.
2. Subir el contenido de este proyecto (incluida `.github/workflows/create-short.yml`) al repositorio, preferentemente mediante Codex conectado a GitHub.
3. En GitHub, abrir `Actions` → `Crear Short de prueba (sin publicar)` → `Run workflow`.
4. Una vez terminado, abrir esa ejecución, sección `Artifacts`, descargar `short-ciencia-demo` y reproducir el MP4 desde el móvil.
5. Revisar la calidad antes de añadir cualquier automatismo de publicación.

## Local (opcional)

```bash
sudo apt-get install -y ffmpeg espeak-ng fonts-dejavu-core
python -m pip install -r requirements.txt
python scripts/render.py --out output
```

Si no tienes `espeak-ng`, usa `python scripts/render.py --silent-test --out output` para probar solo el montaje (sin narración).

## Límites y siguiente fase

- Las imágenes son diagramas procedimentales, **no** vídeo fotorrealista de IA.
- `espeak-ng` es una voz robótica: habrá que sustituirla por una voz libre con licencia compatible y calidad superior (por ejemplo, Piper y un modelo de voz verificado).
- El guion de ejemplo está escrito y requiere revisión de hechos; no hay generación automática de guiones por LLM todavía.
- No hay publicación ni gestión de credenciales de YouTube. Es deliberado.
- Las ejecuciones de GitHub Actions están sujetas a políticas, cuotas técnicas y disponibilidad. Los artefactos caducan según el período configurado.
- Antes de transformar el MVP en producción autónoma: resolver licencias de voces/modelos, comprobación de afirmaciones, variación de contenido, prevención de publicaciones duplicadas, OAuth de YouTube y seguridad de secretos.
