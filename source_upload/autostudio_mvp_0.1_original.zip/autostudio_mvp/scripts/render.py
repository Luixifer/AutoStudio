#!/usr/bin/env python3
"""Offline-first educational Short MVP. No paid APIs or external assets.
Not an autonomous research/AI video generator: reviewed scripts only.
"""
import argparse, json, math, os, subprocess, textwrap, wave, array
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_B='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def call(args):
    subprocess.run(args,check=True)

def draw_scene(scene, number, output):
    w,h=720,1280
    im=Image.new('RGB',(w,h)); p=im.load()
    for y in range(h):
        for x in range(w):
            r=8+int(y/h*11); g=19+int(y/h*19); b=37+int(y/h*34)
            p[x,y]=(r,g,b)
    d=ImageDraw.Draw(im)
    # Three distinctive and geometrically accurate schematic styles, never photorealistic claims
    cx,cy=360,510
    if scene['visual']=='ocean':
        for i in range(1,8):
            d.ellipse((cx-30*i,cy-30*i,cx+30*i,cy+30*i),outline=(23,110+i*10,170+i*7),width=4)
        for i in range(12):
            x=(i*173+93)%w; y=(i*227+145)%800+110
            d.ellipse((x,y,x+6+i%5,y+6+i%5),fill=(70,171,206))
    elif scene['visual']=='vent':
        d.polygon([(110,780),(240,590),(278,690),(360,490),(435,700),(520,560),(630,780)],fill=(47,87,102))
        d.line([(345,770),(345,480)],fill=(234,134,69),width=24)
        for i in range(14):
            x=335+int(math.sin(i*2.1)*100); y=470-i*21
            d.ellipse((x-13,y-13,x+13,y+13),outline=(226,142,95),width=3)
    else:
        for i in range(6):
            x=130+i*85;y=400+int(math.sin(i*1.3)*110)
            d.ellipse((x-24,y-24,x+24,y+24),fill=(45,181,175))
            if i:d.line((130+(i-1)*85,400+int(math.sin((i-1)*1.3)*110),x,y),fill=(165,239,224),width=6)
    title_font=ImageFont.truetype(FONT_B,51)
    body_font=ImageFont.truetype(FONT,34)
    small_font=ImageFont.truetype(FONT_B,25)
    d.text((45,70),f'CIENCIA  /  {number:02}',font=small_font,fill=(89,223,207))
    title=scene['title'].upper()
    lines=textwrap.wrap(title,width=22)
    yy=840
    for line in lines:
        d.text((44,yy),line,font=title_font,fill=(248,252,255)); yy+=66
    for line in textwrap.wrap(scene['caption'],width=34):
        d.text((44,yy+20),line,font=body_font,fill=(187,208,224)); yy+=49
    d.rectangle((42,1187,678,1193),fill=(60,102,120))
    d.rectangle((42,1187,42+int(636*(number/3)),1193),fill=(88,223,204))
    im.save(output)

def make_silence(wav_path,secs):
    with wave.open(str(wav_path),'w') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(22050)
        w.writeframes(bytes(22050*2*secs))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--script',default=str(ROOT/'scripts'/'ocean.json'))
    ap.add_argument('--out',default='output')
    ap.add_argument('--silent-test',action='store_true',help='CI/local render test without voice; not for publication')
    args=ap.parse_args()
    data=json.loads(Path(args.script).read_text(encoding='utf8'))
    if len(data['scenes'])!=3: raise SystemExit('MVP expects exactly three scenes')
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    segments=[]
    import shutil
    if not args.silent_test and not shutil.which('espeak-ng'):
        raise SystemExit('espeak-ng missing. Install it or use --silent-test for an animation test.')
    for i,scene in enumerate(data['scenes'],1):
        image_path=out/f'scene{i}.png'; wav_path=out/f'scene{i}.wav'; mp4=out/f'scene{i}.mp4'
        draw_scene(scene,i,image_path)
        if args.silent_test: make_silence(wav_path,5)
        else:
            call(['espeak-ng','-v','es','-s','135','-w',str(wav_path),scene['voice']])
        # Loop still with gentle cinematic zoom and cross-compatibility CPU encoding.
        probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(wav_path)],capture_output=True,text=True,check=True)
        duration=max(4,float(probe.stdout.strip())+0.5)
        call(['ffmpeg','-y','-loglevel','error','-loop','1','-framerate','25','-i',str(image_path),'-i',str(wav_path),'-vf','zoompan=z=min(zoom+0.00025\\,1.12):d=1:s=720x1280:fps=25,format=yuv420p','-r','25','-t',str(duration),'-c:v','libx264','-preset','ultrafast','-crf','25','-c:a','aac','-b:a','96k','-shortest',str(mp4)])
        segments.append(mp4)
    txt=out/'concat.txt'; txt.write_text(''.join("file '"+x.name+"'\n" for x in segments))
    final=out/'short_ciencia_demo.mp4'
    call(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(txt),'-c','copy',str(final)])
    (out/'metadata.json').write_text(json.dumps({'title':data['title'],'sources':data['sources'],'disclosure':'All illustrations are stylized diagrams, not real underwater footage.','publication':'disabled'},ensure_ascii=False,indent=2))
    print('VIDEO:',final.resolve(),'BYTES:',final.stat().st_size)

if __name__=='__main__': main()
